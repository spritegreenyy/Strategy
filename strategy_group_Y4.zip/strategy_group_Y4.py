from __future__ import annotations

from lumibot.strategies import Strategy as BaseStrategy
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression, Ridge

# We used ChatGPT (GPT-4.1/GPT-4 class large language model) 
# to assist in refining the trading strategy code
# and improving the clarity and organisation of explanations in our assignment.
# The AI tool was used as a support tool for coding assistance, and language refinement.
# We are fully responsible for the design decisions, implementation logic, and overall quality of the submitted work.


class Strategy(BaseStrategy):
    """
    Regime (SPY) + Sector Rotation (Top-K) with ML:
    - Regime model: Logistic Regression predicts SPY 5D-up probability
    - Alpha model: Ridge predicts sector 5D forward return
    - Position sizing: inverse-vol on selected sectors
    - Defensive allocation (risk-off): SPLV
    """

    def initialize(self):
        self.sleeptime = "1D"

        # Universe
        self.market = "SPY"
        self.sectors = ["XLK", "XLF", "XLE", "XLV", "XLY", "XLP"]
        self.defensive = "SPLV"

        # Rebalance & training
        self.lookback = 120          # training window length (days)
        self.rebalance_freq = 5      # rebalance every 5 trading days
        self.day_count = 0

        # Signals
        self.top_k = 3
        self.horizon = 5             # predict forward 5 trading days
        self.risk_threshold = 0.55   # prob_up threshold for risk-on

        # Portfolio constraints
        self.cash_buffer = 0.05      # keep 5% cash
        self.max_weight = 0.50       # cap per-asset weight (within sleeve)
        self.no_trade_band = 0.03    # skip trades if weight change < 3%

        # Models
        self.regime_model = LogisticRegression(max_iter=2000, solver="lbfgs")
        self.ridge_alpha = 10.0      # ridge regularization strength

        self.log_message("Initialized: ML Regime + Sector Rotation (hardened)")

    # ---------- Helpers ----------
    def _get_closes(self, bars) -> pd.Series | None:
        """Robustly extract close series from lumibot bars object."""
        if bars is None:
            return None

        # Common: bars.df exists
        if hasattr(bars, "df"):
            df = bars.df
            if isinstance(df, pd.DataFrame):
                for col in ["close", "Close"]:
                    if col in df.columns:
                        s = df[col].astype(float)
                        return s.dropna()
        # Some versions: bars behaves like dict / DataFrame-like
        try:
            if isinstance(bars, pd.DataFrame):
                for col in ["close", "Close"]:
                    if col in bars.columns:
                        return bars[col].astype(float).dropna()
            if hasattr(bars, "__getitem__"):
                s = bars["close"]
                if isinstance(s, (pd.Series, pd.DataFrame)):
                    if isinstance(s, pd.DataFrame) and "close" in s.columns:
                        return s["close"].astype(float).dropna()
                    if isinstance(s, pd.Series):
                        return s.astype(float).dropna()
        except Exception:
            pass

        return None

    def _build_features_from_close(self, close: pd.Series) -> pd.DataFrame:
        """Build feature matrix from close prices (daily)."""
        r1 = close.pct_change()

        feats = pd.DataFrame({
            "mom5": r1.rolling(5).sum(),
            "mom20": r1.rolling(20).sum(),
            "mom60": r1.rolling(60).sum(),
            "vol20": r1.rolling(20).std(),
        })

        return feats.dropna()

    def _forward_return(self, close: pd.Series, horizon: int) -> pd.Series:
        """Forward horizon-day return aligned at time t: (P_{t+h}/P_t - 1)."""
        return close.pct_change(horizon).shift(-horizon)

    def _target_weight(self, symbol: str, target_w: float, portfolio_value: float):
        """Trade symbol toward target portfolio weight."""
        price = self.get_last_price(symbol)
        if price is None or price <= 0 or portfolio_value <= 0:
            return

        position = self.get_position(symbol)
        current_qty = float(position.quantity) if position is not None else 0.0
        current_w = (current_qty * price) / portfolio_value

        # no-trade band to reduce churn
        if abs(target_w - current_w) < self.no_trade_band:
            return

        target_value = portfolio_value * target_w
        target_qty = target_value / price
        delta_qty = target_qty - current_qty

        if abs(delta_qty) <= 1e-6:
            return

        side = "buy" if delta_qty > 0 else "sell"
        order = self.create_order(asset=symbol, quantity=abs(delta_qty), side=side)
        self.submit_order(order)

    # ---------- Main loop ----------
    def on_trading_iteration(self):
        self.day_count += 1
        if self.day_count % self.rebalance_freq != 0:
            return

        portfolio_value = self.get_portfolio_value()
        if portfolio_value is None or portfolio_value <= 0:
            return

        invest_weight = 1.0 - self.cash_buffer

        # ----- Regime: SPY -----
        spy_bars = self.get_historical_prices(self.market, length=self.lookback + 70, timestep="1D")
        spy_close = self._get_closes(spy_bars)
        if spy_close is None or len(spy_close) < 80:
            return

        X_spy = self._build_features_from_close(spy_close)
        if len(X_spy) < 30:
            return

        fwd_spy = self._forward_return(spy_close, self.horizon)
        y_spy = (fwd_spy > 0).astype(int)

        # align and drop NaNs properly
        y_spy = y_spy.loc[X_spy.index].dropna()
        X_spy = X_spy.loc[y_spy.index]

        # guard: logistic regression needs 2 classes
        if y_spy.nunique() < 2:
            prob_up = 0.0
        else:
            try:
                self.regime_model.fit(X_spy.values, y_spy.values)
                prob_up = float(self.regime_model.predict_proba(X_spy.iloc[-1:].values)[0][1])
            except Exception:
                prob_up = 0.0

        # ----- Risk-off -----
        if prob_up < self.risk_threshold:
            self.log_message(f"Risk-OFF | prob_up={prob_up:.3f}")

            # liquidate sectors
            for asset in self.sectors:
                self._target_weight(asset, 0.0, portfolio_value)

            # allocate to defensive
            self._target_weight(self.defensive, invest_weight, portfolio_value)
            return

        # ----- Risk-on: predict sectors -----
        self.log_message(f"Risk-ON | prob_up={prob_up:.3f}")

        predicted = {}
        sector_vol = {}

        for asset in self.sectors:
            bars = self.get_historical_prices(asset, length=self.lookback + 70, timestep="1D")
            close = self._get_closes(bars)
            if close is None or len(close) < 80:
                continue

            X = self._build_features_from_close(close)
            if len(X) < 30:
                continue

            fwd = self._forward_return(close, self.horizon)
            y = fwd.loc[X.index].dropna()
            X = X.loc[y.index]

            if len(X) < 30:
                continue

            try:
                model = Ridge(alpha=self.ridge_alpha)
                model.fit(X.values, y.values)
                pred = float(model.predict(X.iloc[-1:].values)[0])
            except Exception:
                continue

            predicted[asset] = pred

            # vol for sizing (use last vol20 from features)
            v = float(X["vol20"].iloc[-1])
            if np.isfinite(v) and v > 0:
                sector_vol[asset] = v

        if not predicted:
            return

        # Select Top-K with positive predicted return
        ranked = sorted(predicted.items(), key=lambda kv: kv[1], reverse=True)
        selected = [sym for sym, pr in ranked if pr > 0][: self.top_k]

        if not selected:
            # if no positive alpha, go defensive (still risk-on regime, but alpha absent)
            for asset in self.sectors:
                self._target_weight(asset, 0.0, portfolio_value)
            self._target_weight(self.defensive, invest_weight, portfolio_value)
            return

        # Inverse-vol weights on selected
        inv_sum = 0.0
        vols = {}
        for sym in selected:
            v = sector_vol.get(sym, np.nan)
            if np.isfinite(v) and v > 0:
                vols[sym] = v
                inv_sum += 1.0 / v

        if inv_sum <= 0:
            return

        # preliminary weights
        w = {sym: (1.0 / vols[sym]) / inv_sum for sym in vols.keys()}

        # cap weights and re-normalize (leave leftover as cash)
        for sym in list(w.keys()):
            w[sym] = min(w[sym], self.max_weight)

        w_sum = sum(w.values())
        if w_sum > 0:
            scale = invest_weight / w_sum
            for sym in w:
                w[sym] *= scale
        else:
            return

        # Set targets: non-selected sectors to 0
        for asset in self.sectors:
            if asset not in w:
                self._target_weight(asset, 0.0, portfolio_value)

        # Selected weights
        for sym, weight in w.items():
            self._target_weight(sym, weight, portfolio_value)

        # Defensive off
        self._target_weight(self.defensive, 0.0, portfolio_value)